const { GoogleAuth } = require("google-auth-library");
const { google } = require("googleapis");
const async = require("async");
const dotenv = require("dotenv");

dotenv.config({ path: "./config.env" });

const CLIENT_ID =
  "2885644574-oh58mo92k60jb14lpaftre37u8j3kba3.apps.googleusercontent.com";
const CLIENT_SECRET = "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";
const REDIRECT_URI = "https://developers.google.com/oauthplayground";

const REFRESH_TOKEN =
  "1//04Zq6ysixP36eCgYIARAAGAQSNgF-L9Ir2wdwxWXVOHpQS0CYRgosxqHECxjNcrlEeBrZh75g5cp5AMkBP1WnIxr5RRYF-V9wlQ";

function shareFile(fileId, targetUserEmail, targetDomainName) {
  // Get credentials and build service
  // TODO (developer) - Use appropriate auth mechanism for your app
  const oauth2Client = new google.auth.OAuth2(
    CLIENT_ID,
    CLIENT_SECRET,
    REDIRECT_URI
  );

  oauth2Client.setCredentials({ refresh_token: REFRESH_TOKEN });

  const auth = new GoogleAuth({
    keyFile: process.env.GOOGLE_APPLICATION_CREDENTIALS,
    key: "",
    scopes: "https://www.googleapis.com/auth/drive",
  });
  const service = google.drive({
    version: "v3",
    auth: oauth2Client,
  });

  let id;
  const permissions = [
    {
      type: "user",
      role: "writer",
      emailAddress: targetUserEmail, // 'user@partner.com',
    },
    {
      type: "user",
      role: "writer",
      emailAddress: targetDomainName, // 'user@partner.com',
    },
    // {
    //   type: "domain",
    //   role: "viewer",
    //   domain: targetDomainName, // 'example.com',
    // },
  ];
  // Using the NPM module 'async'
  try {
    async.eachSeries(permissions, function (permission) {
      service.permissions
        .create({
          resource: permission,
          fileId: fileId,
          fields: "id",
        })
        .then(function (result) {
          id = result.data.id;
          console.log("Permission Id:", id);
        })
        .catch(function (err) {
          // TODO(developer) - Handle error
          console.log("err", err);
          throw err;
        });
    });
    return id;
  } catch (err) {
    // TODO(developer) - Handle error
    console.log("err", err);
    throw err;
  }
}

shareFile(
  "1xtHnBESVv2Os-PfNKPsyWqBC40c2zTpZ",
  "ayush.nextin@gmail.com",
  "itw.ayushs@gmail.com"
);
