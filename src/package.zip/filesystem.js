const express = require("express");
const router = express();
const cookieParser = require("cookie-parser");
const fs = require("fs");
const multer = require("multer");

const Storage = multer.diskStorage({
  destination: "public/uploads",
  filename: (req, file, cb) => {
    cb(null, file.originalname);
  },
});

const upload = multer({
  storage: Storage,
}).single("testImage");

router.use(cookieParser());

// router.get(`/book`, (req, res) => {
//   BOOK.find()
//     .then((data) => {
//       res.status(200).json(data);
//     })
//     .catch((err) => {
//       res.status(400).send(err);
//     });
// });

router.post("/book", (req, res) => {
  upload(req, res, (err) => {
    if (err) {
      console.log("err", err);
    } else {
      console.log("data", req.body);
    }
  });
});
